import os
from os.path import abspath, dirname, join
import datetime

# Configuration Settings

# APP configs

# Get current Date/Time
now = datetime.datetime.now()

APP_NAME = "Audeince Builder API"
APP_ROOT = os.path.dirname(os.path.realpath(__file__))
ROOT_URL = "/atlas_api"  # Should be changed to match path for Apache (i.e., /[app_name]). No forward slash at end.
ROOT_DOMAIN = ""
APP_VERSION = "1"
COPYRIGHT_YEAR = now.year
TEMPLATES_PATH = "./templates"
DEBUG = False


# # MOUNT_PATH_VARIABLES

# DBKS_FILE_PATH = "/mnt/crm-7cast/"
# BLOB_FILE_PATH = "/data/"

# # PINOT TABLES

# STORE_MASTER_TABLE = "crm_store_master"
# PRODUCT_MASTER_TABLE = "productmaster_latest_slin"

# CUSTOMER_MASTER_TABLE = "crm_cust_master"

# UC_CONTROL_LIST_TABLE = "crm_universal_control_list"
# MARKETABILITY_TABLE = "crm_preference_center"

# TIERS_TABLE = "crm_cust_prob_alive_path_seg"
# TRIPS_TABLE = "crm_cust_trips"

# # RFMA tables

# DAYPART_RFMA_TABLE = "crm_cust_daypart_rfma"
# CHANNEL_RFMA_TABLE = "crm_cust_txn_channel_rfma"

# # product rfma tables
# PRODUCT_RFMA_TABLE = "crm_cust_prod_rfma"
# DAYPART_PRODUCT_RFMA_TABLE = "crm_cust_daypart_product_rfma"
# TXN_CHANNEL_PRODUCT_RFMA_TABLE = "crm_cust_txn_channel_product_rfma"


# # CONSTANTS

# CUSTOMER_AGE_MIN = 5
# CUSTOMER_AGE_MAX = 110


# # EXPERIMENT PLATFORM VARIABLES
# EXPERIMENT_MEMBER_COHORT_TBL_PATH = "/mnt/SPARK_TABLES/DIGITAL/CRM/crm_experiment_cohort"
# EXPERIMENT_MEMBER_COHORT_TBL_NAME = "digital.crm_experiment_cohort"
