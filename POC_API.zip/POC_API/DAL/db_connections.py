__author__ = 'Vennam'
__copyright__ = "Copyright"
__version__ = "1.0.0"
__status__ = "pre-release"


from app__init__ import app

import logging
import os
import sys
# import prestodb
import datetime as dt

import psycopg2
logging.basicConfig(level=logging.WARNING)


class DB_Connections:


    def get_postgres_conn(self):
        """
        Connection to Presto  database

        :return: presto Connection
        """
        try:
            
            postgres_conn = psycopg2.connect(database="pdmdpa", user="svennam", password="18RKmYX05", host="pdmalpha-dev.cluster-cflkn4kaxikq.us-east-1.rds.amazonaws.com", port="5432")

            return postgres_conn

        except Exception as ex:
            logging.error(
                "Error while connecting to Postgres Conn. Error: %s" % (str(ex)))
            return False

  