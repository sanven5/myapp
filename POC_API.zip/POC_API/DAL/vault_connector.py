import logging
import os
import requests

logging.basicConfig(level=logging.WARNING)


class KeyVaultManager(object):
    """
    This class manages connection to key vault using client id and secret of service principal.
    It provides method to access secrets from key vault.
    """

    def __init__(self):
        self.azure_tenant_id = os.environ.get('AZURE_TENANT_ID')
        self.sp_client_id = os.environ.get('SP_CLIENT_ID')
        self.sp_client_secret = os.environ.get('SP_CLIENT_SECRET')
        self.resource = os.environ.get('RESOURCE')
        self.key_vault_url = os.environ.get('KEY_VAULT_URL')
        self.api_version = os.environ.get('API_VERSION')

    def connect_key_vault(self):
        """
        To connect to key vault
        :return secret data dict read from key vault secrets using tokens
        """
        try:
            URL = "https://login.microsoftonline.com/" + self.azure_tenant_id + "/oauth2/token"

            payload = {'grant_type': 'client_credentials',
                       'client_id': self.sp_client_id,
                       'client_secret': self.sp_client_secret,
                       'resource': self.resource}
            headers = {
                'content-type': "application/x-www-form-urlencoded"
            }
            response = requests.request("POST", URL, data=payload, headers=headers)
            result = self.check_response(response)
            if result:
                token = result.get("access_token")
                return token
        except Exception as ex:
            logging.error("Key Vault Connection: error while getting oauth token for key vault access:%s" % (str(ex)))

    def get_secret_value(self, token, secret_key):
        """
        To get value of specified secret from key vault

        :param token: token to connect to key vault
        :param secret_key: secret key to fetch value
        :return value of specified secret
        """
        if token and self.key_vault_url and self.api_version:
            try:
                URL = self.key_vault_url + "/secrets/" + secret_key + "/?api-version=" + self.api_version
                headers = {
                    "Authorization": "Bearer %s" % token
                }
                response = requests.request("GET", URL, headers=headers)
                result = self.check_response(response)
                return result.get("value")
            except Exception as ex:
                logging.error("Key vault Error: while getting value of secret %s Error: %s" % (secret_key, str(ex)))
        else:
            logging.error(
                "Please verify token, keyvault URL and API version, as its needed to get secrets from Key vault")

    def check_response(self, response):
        """
        check response from rest endpoint
        :param response: response from rest endpoint
        :return:respose in json format
        """

        if response.ok:
            return response.json()
        else:
            msg = "Key Vault Access http_status_code: %s" % str(response.status_code)
            try:
                msg = response.json()['message']
            except:
                msg = response.text
            finally:
                logging.error("Key Vault Access Error: response: %s" % str(msg))
            exit(1)
