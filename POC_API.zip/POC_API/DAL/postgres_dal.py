__author__ = 'Vennam'
__copyright__ = "Copyright"
__version__ = "1.0.0"
__status__ = "pre-release"

import logging
from DAL import DB_Connections

from Services.cohort_stats_builder import CohortStatsBuilder
from Services.utils import *
from collections import namedtuple
from psycopg2.extras import RealDictCursor

from flask import json

import simplejson as sjson
from flask import Response

from app__init__ import app


class Postgres_DAL:

    # API Implemented
    #####################
    def get_users_query(self, user_email):
        """
        :param query: input query
        :return: query output
        """

        try:
            cDB = DB_Connections()
            con = cDB.get_postgres_conn()
            cur = con.cursor(cursor_factory=RealDictCursor)
            if user_email == '':
                query = "select * from raw_pega.webapp_person_details"
            else:
                print(f" user email is {user_email}")
                query = f"select * from raw_pega.webapp_person_details where email = '{user_email}' "
            cur.execute(query)
            return_rows = cur.fetchall()
            return return_rows
            
        except Exception as exc:

            logging.info(f"Error in fetching User Records")
            return []

    def post_users_query(self, user_obj):
        """
        :param query: input query
        :return: query output
        """
        try:
            cDB = DB_Connections()
            con = cDB.get_postgres_conn()
            cur = con.cursor()
            cur.execute('INSERT INTO raw_pega.webapp_person_details (email, fname, lname, address) VALUES (%s, %s, %s, %s)', (user_obj["email"], user_obj["fname"], user_obj["lname"], user_obj["address"]))
            # res =  cur.execute("""
            # INSERT INTO  raw_pega.webapp_person_details (email, fname, lname, address)
            # VALUES (%s, %s, %s, %s)
            # """,
            # (user_obj["email"], user_obj["fname"], user_obj["lname"], user_obj["address"]))
            # print("""
            # INSERT INTO  raw_pega.webapp_person_details (email, fname, lname, address)
            # VALUES (%s, %s, %s, %s)
            # """,
            # (user_obj["email"], user_obj["fname"], user_obj["lname"], user_obj["address"]))
            # print(res)
            con.commit()
            con.close()
            return True
        except Exception as e:

            print(f"Error in updating User Records :: {e}")
            return False

    def delete_users_query(self, user_email):
        """
        :param query: input query
        :return: query output
        """

        try:
            cDB = DB_Connections()
            con = cDB.get_postgres_conn()
            cur = con.cursor()
            query = f"DELETE from raw_pega.webapp_person_details WHERE EMAIL= '{user_email}' "
            cur.execute(query)
            con.commit()
            con.close()
            return True
            
        except Exception as exc:

            print(f"Error in deleting User Records :: {exc}")
            return []



    def update_users_query(self, user_obj):
        """
        :param query: input query
        :return: query output
        """
        try:
            cDB = DB_Connections()
            con = cDB.get_postgres_conn()
            cur = con.cursor()
            cur.execute('UPDATE raw_pega.webapp_person_details SET fname=%s, lname=%s, address=%s WHERE email=%s', (user_obj["fname"], user_obj["lname"], user_obj["address"], user_obj["email"]))
            # res =  cur.execute("""
            # INSERT INTO  raw_pega.webapp_person_details (email, fname, lname, address)
            # VALUES (%s, %s, %s, %s)
            # """,
            # (user_obj["email"], user_obj["fname"], user_obj["lname"], user_obj["address"]))
            # print("""
            # INSERT INTO  raw_pega.webapp_person_details (email, fname, lname, address)
            # VALUES (%s, %s, %s, %s)
            # """,
            # (user_obj["email"], user_obj["fname"], user_obj["lname"], user_obj["address"]))
            # print(res)
            con.commit()
            con.close()
            return True
        except Exception as e:

            print(f"Error in updating User Records :: {e}")
            return False






