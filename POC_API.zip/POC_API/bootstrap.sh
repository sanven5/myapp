#!/bin/bash

python3 create_config.py

cp .databrickscfg /root/
cp .databricks-connect /root/

python atlas_api.py