# imports
import memcache

# mc = memcache.Client(['127.0.0.1:11211'], debug=0)

#placeholder to implement caching
# class Cached_Results:

