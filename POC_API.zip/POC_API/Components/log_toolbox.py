__author__ = 'Vennam'
__copyright__ = "Copyright"
__version__ = "1.0.0"
__maintainer__ = "Vennam"
__email__ = ""
__status__ = "pre-release"

import datetime

class Log_Toolbox:


	def log_event(self,logText,fileOutput):
		"""
		Writes text to logfile and prints to screen
	
		:param logText: Text to log
		:param fileOutput: File to output text to.
		"""
	
		#Datetime format
		dtFormat = '%Y-%m-%d %H:%M:%S %Z'
		d = datetime.datetime.now()
		dt = d.strftime(dtFormat)
		
		flog = open(fileOutput,'w')
	
		print("{0}| {1}".format(dt,logText))
		fileOutput.write("{0}| {1}\n".format(dt,logText))

	def log_event_2(self,logText,fileOutput):
		"""
		Writes text to logfile and prints to screen
	
		:param logText: Text to log
		:param fileOutput: File to output text to.
		"""
	
		#Datetime format
		dtFormat = '%Y-%m-%d %H:%M:%S %Z'
		d = datetime.datetime.now()
		dt = d.strftime(dtFormat)
	
		flog = open(fileOutput,'a')
		print("{0}| {1}".format(dt,logText))
		flog.write("{0}| {1}\n".format(dt,logText))
		flog.close()
	
	def log_free_text(self,logText,fileOutput):
	    """
	    Writes text to logfile and prints to screen
	
	    :param logText: Text to log
	    :param fileOutput: File to output text to.
	    """
	
	    print("{0}".format(logText))
	    fileOutput.write("{0}\n".format(logText))
