class CheckUserCriteria:

    ########### helper functions to check user input conditions ##############

    def is_prod_rfma_checked(self, user_input):
        return (user_input["check_cust_prod_inclusion"]
                and
                any(
                ['All' not in user_input['select_cust_prod_vendor_inclusion'],
                 'All' != user_input['select_cust_prod_level1_inclusion'],
                 'All' != user_input['select_cust_prod_level2_inclusion']]))

    def is_prod_rfma_exclusion_checked(self, user_input):
        return (user_input["check_cust_prod_exclusion"]
                and
                any(['All' not in user_input['select_cust_prod_vendor_exclusion'],
                     'All' != user_input['select_cust_prod_level1_exclusion'],
                    'All' != user_input['select_cust_prod_level2_exclusion']]))

    def is_daypart_prod_rfma_checked(self, user_input):
        return (user_input["check_daypart_prod_inclusion"]
                and
                any(
                ['All' not in user_input['select_daypart_prod_vendor_inclusion'],
                 'All' != user_input['select_daypart_prod_level1_inclusion'],
                 'All' != user_input['select_daypart_prod_level2_inclusion']]))

    def is_txnchannel_prod_rfma_checked(self, user_input):
        return (user_input["check_txn_channel_prod_inclusion"]
                and
                any(
                ['All' not in user_input['select_txn_channel_prod_vendor_inclusion'],
                 'All' != user_input['select_txn_channel_prod_level1_inclusion'],
                 'All' != user_input['select_txn_channel_prod_level2_inclusion']]))

    def is_txnchannel_rfma_checked(self, user_input):
        return (user_input['check_7Now_rfma']
                or
                user_input['check_MobileCheckout_rfma']
                or user_input['check_Fuel_rfma']
                or user_input['check_7rewards_rfma'])

    def is_marketability_checked(self, user_input):
        return (user_input["email_marketable"] != "" or user_input[
                "sms_marketable"] != "" or user_input["push_marketable"] != "")
