import logging
import re

from app__init__ import app

from Services.query_builder import QueryBuilder
from Services.query_utils import QueryUtils
from Services.check_user_inputs import CheckUserCriteria
query_builder_obj = QueryBuilder()
query_utils_obj = QueryUtils()
check_user_input_obj=CheckUserCriteria()

class CohortCreationController:

    channel_codes = {'7now': 21, 'mobile_checkout': 20, 'Fuel': 55}
    ALL = 'All'

    ########### functions to call query buiding funcitons ##############
    

    def create_prod_rfma_query(self, query, user_input):
        return query_builder_obj.check_and_call_filter(
            query, 'prod', True,
            'Product', lambda: query_builder_obj.product_cust_attr(
                user_input, 'cust_prod', app.config["PRODUCT_RFMA_TABLE"],
                '_inclusion'),
            join_key='unq_member_id')

    def create_prod_excl_rfma_query(self, query, user_input):
        return query_builder_obj.check_and_call_filter(
            query, 'prod', True,
            'Product', lambda: query_builder_obj.product_cust_attr(
                user_input, 'cust_prod', app.config["PRODUCT_RFMA_TABLE"],
                '_exclusion'), inclusion=False,
            join_key='unq_member_id')

    def create_daypart_prod_rfma_query(self, query, user_input):
        return query_builder_obj.check_and_call_filter(
            query, 'daypartprod', True, 'DaypartProduct', lambda: query_builder_obj.product_cust_attr(
                user_input, 'daypart_prod', app.config["DAYPART_PRODUCT_RFMA_TABLE"],
                '_inclusion', other_param='day_part', other_param_value=user_input
                ['select_daypart_prod_inclusion'].upper()),
            join_key='unq_member_id')

    def create_txnchannel_prod_rfma_query(self, query, user_input):
        return query_builder_obj.check_and_call_filter(
            query, 'txnxhannelprod', True,
            'TxnChannelProduct', lambda: query_builder_obj.product_cust_attr(
                user_input, 'txn_channel_prod', app.config["TXN_CHANNEL_PRODUCT_RFMA_TABLE"],
                '_inclusion', other_param='txn_channel',
                other_param_value=self.channel_codes[user_input['select_txn_channel_prod_inclusion']]),
            join_key='unq_member_id')

    def create_marketability_query(self, query, user_input):
        return query_builder_obj.check_and_call_filter(
            query, 'mrkt', True, 'Marketable', lambda: query_builder_obj.check_marketability(user_input),
            join_key='loyalty_id')

    def create_txnchannel_rfma_query(self, query, user_input):
        return query_builder_obj.check_and_call_filter(query, 'chn_rfma', True,
                                                       'Channel', lambda: query_builder_obj.check_channel_rfma(
                                                           user_input, 'dummy'),
                                                       join_key='unq_member_id')

    def create_daypart_rfma_query(self, query, user_input):
        return query_builder_obj.check_and_call_filter(
            query, 'chn_rfma', user_input['select_daypart_rfma'] != "",
            'Daypart', lambda: query_builder_obj.check_daypart_rfma(
                user_input, 'dummy'), join_key='unq_member_id')

    def create_tiers_query(self, query, user_input):
        return query_builder_obj.check_and_call_filter(
            query, 'tier', user_input['check_frequency_tier'] or user_input['check_recency_tier'],
            'tiers', lambda: query_builder_obj.check_start_end_customer_segments(
                user_input, 'cust_id', {'frequency_tier': 'seg_trip_freq', 'recency_tier': 'freq_based_recency_seg'}),
            join_key='unq_member_id')

    def create_primary_segment_query(self, query, user_input):
        return query_builder_obj.check_and_call_filter(
            query, 'trip', user_input['primary_trip_mission'] != "" or user_input['primary_daypart'] != "",
            'MissionDaypart', lambda: query_builder_obj.check_primary_segments(
                user_input, 'unq_member_id',
                {'primary_trip_mission': 'primary_trip_mission', 'primary_daypart': 'primary_day_part'}),
            join_key='unq_member_id')

    def create_suppression_lids_query(self, base_query, user_input):
        final_query = base_query
        if user_input['uc_flag']:
            query = query_builder_obj.check_uc(user_input)
            query = query_utils_obj.fix_sql(query)
            query = query+(f")uc" if query.strip().endswith(
                "limit 100000000") else f" limit 100000000)uc")
            final_query = base_query + \
                f""" LEFT JOIN ({query}_excl ON cust.unq_member_id=uc_excl.member_id WHERE uc_excl.member_id IS NULL"""
        return final_query

    # build query controller for cohort extraction

    def get_cohort_values(self, user_input):
        """ Controls flow of the different filters to get cohort

        Args:
            user_input (dict): user selection dictionary

        Returns:
            str: query to extract customers with user conditions
        """
        query = ""

        # get customer attributes
        query = query + query_builder_obj.get_cust_attr(user_input)

        # product inclusion
        if check_user_input_obj.is_prod_rfma_checked(user_input):
            query = self.create_prod_rfma_query(query, user_input)

        # product exclusion

        if check_user_input_obj.is_prod_rfma_exclusion_checked(user_input):
            query = self.create_prod_excl_rfma_query(query, user_input)
        # daypart product inclusion
        if check_user_input_obj.is_daypart_prod_rfma_checked(user_input):
            query = self.create_daypart_prod_rfma_query(query, user_input)

        # txn channel product inclusion
        if check_user_input_obj.is_txnchannel_prod_rfma_checked(user_input):
            query = self.create_txnchannel_prod_rfma_query(query, user_input)

        # marketability
        if check_user_input_obj.is_marketability_checked(user_input):
            query = self.create_marketability_query(query, user_input)

        # txn channel rfma
        if check_user_input_obj.is_txnchannel_rfma_checked(user_input):
            query = self.create_txnchannel_rfma_query(query, user_input)

        # daypart rfma
        query = self.create_daypart_rfma_query(query, user_input)

        # recency & frequency tiers
        query = self.create_tiers_query(query, user_input)

        # daypart and trip mission
        query = self.create_primary_segment_query(query, user_input)

        # supress lids
        query = self.create_suppression_lids_query(query, user_input)
        logging.info(query)
        return query

    def get_counts(self, user_input):
        """Create query to get cohort count after each set of filters

        Args:
            user_input (dict): user filters

        Returns:
            dict: dictionary of queries with query description as keys
        """
        count_dict = {}
        cust_count_dict, query = query_builder_obj.get_cust_attr_counts(user_input)
        count_dict = dict(count_dict, **cust_count_dict)

        # PRODUCT INCLUSION
        if check_user_input_obj.is_prod_rfma_checked(user_input):
            query = self.create_prod_rfma_query(query, user_input)
            count_dict['Products purchased (inclusion)'] = query

        # PRODUCT EXCLUSION
        if check_user_input_obj.is_prod_rfma_exclusion_checked(user_input):
            query = self.create_prod_excl_rfma_query(query, user_input)
            count_dict['Products purchased (exclusion)'] = query

        # DAYPART PRODUCT INCLUSION
        if check_user_input_obj.is_daypart_prod_rfma_checked(user_input):
            query = self.create_daypart_prod_rfma_query(query, user_input)
            count_dict[f"Products purchased (inclusion) in {user_input['select_daypart_prod_inclusion']}"] = query

        # TXN CHANNEL PRODUCT INCLUSION

        if check_user_input_obj.is_txnchannel_prod_rfma_checked(user_input):
            query = self.create_txnchannel_prod_rfma_query(query, user_input)
            count_dict[f"Products purchased (inclusion) in {user_input['select_txn_channel_prod_inclusion']}"] = query

        # MARKETBILITY
        if check_user_input_obj.is_marketability_checked(user_input):
            query = self.create_marketability_query(query, user_input)
            count_dict[f"Marketability"] = query

        # TXN CHANNEL RFMA
        if check_user_input_obj.is_txnchannel_rfma_checked(user_input):
            query = self.create_txnchannel_rfma_query(query, user_input)
            count_dict[f"Channel activity"] = query

        # DAYPART RFMA
        if(user_input['select_daypart_rfma'] != ""):
            query = self.create_daypart_rfma_query(query, user_input)
            count_dict[f"Daypart activity({user_input['select_daypart_rfma']})"] = query

        # RECENCY AND FREQUENCY TIERS
        if(user_input['check_frequency_tier'] or user_input['check_recency_tier']):
            query = self.create_tiers_query(query, user_input)
            count_dict[f"Recency/Frequency Tiers"] = query

        # DAYPART AND TRIP MISSION
        
        if(user_input['primary_trip_mission'] != "" or user_input['primary_daypart'] != ""):
            query = self.create_primary_segment_query(query, user_input)
            count_dict[f"Primary trip mission/daypart"] = query

        # supress lids
        if user_input['uc_flag']:
            query = self.create_suppression_lids_query(query, user_input)
            count_dict[f"LID suppression(UC)"] = query
        return count_dict
