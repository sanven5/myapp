
import pandas as pd


class DataTransform:

    def dt_cards_viz(self, output):
        output_order = ['7R', '7NOW', 'Fuel', 'MCO']
        return [{"title": output_order[i], "count":output[i]} for i in range(len(output))]

    def dt_horizontal_bar_chart(self, output, type):
        if type == 'freq':
            return {"freqtier": {"title": "Frequency Tiers", "data": [{"name": output[i][0], "steps":output[i][1]}for i in range(len(output))]}}
        if type == 'recency':
            return {"rectier": {"title": "Recency Tiers", "data": [{"name": output[i][0], "steps":output[i][1]}for i in range(len(output))]}}

    def dt_bar_pie_viz(self, output):
        output_df = pd.DataFrame(output, columns=['Daypart', 'Trip Type', 'Count'])
        daypart_counts = output_df.groupby(['Daypart']).sum().reset_index().values.tolist()
        daypart_values = output_df.groupby('Daypart').agg(list).to_dict('index')

        breakdown_dict = dict()
        for daypart in daypart_values:
            breakdown_dict[daypart] = [
                {"category": daypart_values[daypart]['Trip Type'][i],
                 "value": daypart_values[daypart]['Count'][i]}
                for i in range(0, len(daypart_values[daypart]['Trip Type']))]

        ans = [{"category": daypart_counts[i][0], "value":daypart_counts[i][1],
                "breakdown":breakdown_dict[daypart_counts[i][0]]} for i in range(len(daypart_counts))]

        return ans


    def dt_treemap_viz(self, output):
        output_df = pd.DataFrame(output, columns=['Trip Mission', 'Trip Type', 'Count'])
        d = output_df.groupby('Trip Mission').agg(list).to_dict('index')

        breakdown_dict = dict()
        for t in d.keys():
            breakdown_dict[t] = [
                {"name": d[t]['Trip Type'][i],
                 "value": d[t]['Count'][i]}
                for i in range(0, len(d[t]['Trip Type']))]

        return [{"name": key, "children": breakdown_dict[key]} for key in breakdown_dict.keys()]