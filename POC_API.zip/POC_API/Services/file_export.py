import logging
import datetime as dt
import logging
import os

from Services.utils import read_file_to_spark
from app__init__ import app


class FileExport:

    def export_file(self, df, filepath, filename, shuffle=False, progress=True):
        """ Exports hdf5 file

        Args:
            df (vaex df):
            filepath (str): filepath
            filename (str): filename
            shuffle (bool, optional): Shuffle records. Defaults to False.
            progress (bool, optional): Show progress on terminal. Defaults to True.
        """
        if "csv" in filename.split("."):
            df.export_csv(filepath + filename)
        else:
            df.export(filepath + filename, shuffle)

        df.close_files()

    def randomize_df(self, df):
        return df.sample(frac=0.25, random_state=1)

    def export_cohorts(self,
                       df,
                       n_split,
                       target_to_control,
                       filenames,
                       filepath="/mldata/blobmount/cohort_creation/"
                       ):
        """Export cohort file

        Args:
            df ([type]): [description]
            n_split ([type]): [description]
            target_to_control ([type]): [description]
            filenames ([type]): [description]
            filepath (str, optional): [description]. Defaults to "/mldata/blobmount/cohort_creation/".
        """

        logging.info("Starting export_cohorts")
        target_to_control = float(target_to_control)

        if target_to_control < 1:
            test_and_control_lst = df.randomSplit([target_to_control, 1-target_to_control])
            df_target = test_and_control_lst[0]
            df_control = test_and_control_lst[1]
            df_control.toPandas().to_csv(
                filepath + "control_" + dt.datetime.now().strftime("%Y%m%d_%H-%M-%S") + ".csv",
                index=False
            )

            df = df_target
        else:
            # filenames.append("control")
            n_split = n_split

        #S = int(df.shape[0] / n_split)
        #N = int(len(df) / S)
        #cohorts = [df[i * S: (i + 1) * S] for i in range(N)]
        cohorts = df.randomSplit([1/n_split] * (n_split), 100)
        logging.info(f'File names: {filenames}')
    # print(f'{filepath}{filenames[0]}_{dt.datetime.now().isoformat()}_.csv')
        for i in range(0, len(filenames)):
            logging.info((cohorts[i].count()))
            cohorts[i].toPandas().to_csv(
                filepath + filenames[i] + "_" + dt.datetime.now().strftime("%Y%m%d_%H-%M-%S") + ".csv", index=False)

        logging.info("Finished export_cohorts")

    def remove_temp_file(self, filepath):
        try:
            os.remove(filepath + "temp_cohort.hdf5")
        except OSError:
            logging.error("error in removing", exc_info=True)

    def randomize_cohorts(self, df,
                          n_split,
                          target_to_control,
                          filenames,
                          filepath="/mldata/blobmount/cohort_creation/"):

        logging.info("Starting randomize_cohorts")

        self.export_cohorts(df.to_spark(), n_split, target_to_control, filenames, filepath)
        logging.info("Finished randomize_cohorts")

    def place_cohorts(self, export_id_format, cohort_file, number_cohorts, target_to_control, cohort_names):
        df = read_file_to_spark(cohort_file)

        if export_id_format == 'Loyalty-ID':
            df = df[['loyalty_id']]
        else:
            df = df[['unq_member_id']]

        self.randomize_cohorts(
            df,
            number_cohorts,
            target_to_control,
            cohort_names,
            app.config["BLOB_FILE_PATH"])
