import time

from DAL.db_connections import DB_Connections
from app__init__ import app

def timeit(f):
    def timed(*args, **kw):


        ts = time.time()
        result = f(*args, **kw)
        te = time.time()

        print('func:%r took: %2.4f sec' % \
          (f.__name__, te-ts))
        return result

    return timed
  
def read_file_to_spark(cohort_file):
    conn_obj = DB_Connections()
    ks, spark = conn_obj.get_spark_connector()

    df = ks.read_csv(app.config["DBKS_FILE_PATH"] + cohort_file)
    return df