import logging
import re

from app__init__ import app
from datetime import date, timedelta


class CohortStatsBuilder():

    # helper functions
    def get_first_day_last_month(self, format=None):
        # table updates on 4th of every month
        today = date.today().replace(day=1)
        if date.today().day >= 1 and date.today().day <= 5:
            today = (today - timedelta(days=1)).replace(day=1)

        last_day_of_prev_month = today - timedelta(days=1)
        start_day_of_prev_month = today - timedelta(days=last_day_of_prev_month.day)
        if format is not None:
            return str(start_day_of_prev_month.strftime(format))
        return str(start_day_of_prev_month)

    # api data functions

    def get_channel_stats(self, selected_customer_query):
        """ Generate customer counts for channel of transaction (7R,7n,MCO,Fuel loyalty)

        Args:
            selected_customer_query (str): query for user selected criteria

        Returns:
            channel stats query
        """

        return f"""select sum(case when rewards_flag='true' then 1 else 0 end) as rewards,
        sum(case when now_flag='true' then 1 else 0 end) as now,
        sum(case when fuel_loyalty_flag='true' then 1 else 0 end) as fuel_loyalty,
        sum(case when mc_flag='true' then 1 else 0 end) as mc_flag
        from {app.config["CUSTOMER_MASTER_TABLE"]} stats_table
        inner join 
        ({selected_customer_query})B
        on stats_table.unq_member_id=B.unq_member_id"""

    def get_freq_tier_stats(self, selected_customer_query):
        """ Generate freq tier counts 

        Args:
            selected_customer_query (str): query for user selected criteria

        Returns:
            freq tier query
        """

        month = self.get_first_day_last_month()
        return f"""select seg_trip_freq,count(*) 
        from {app.config["TIERS_TABLE"]}  stats_table
        inner join 
        ({selected_customer_query})B
        on stats_table.cust_id=B.unq_member_id
        where month_year='{month}'
        group by seg_trip_freq
        order by count(*)"""

    def get_recency_tier_stats(self, selected_customer_query):
        """ Generate recency tier counts 

        Args:
            selected_customer_query (str): query for user selected criteria

        Returns:
            recency tier query
        """

        month = self.get_first_day_last_month()
        return f"""select freq_based_recency_seg,count(*) 
        from {app.config["TIERS_TABLE"]}  stats_table
        inner join 
        ({selected_customer_query})B
        on stats_table.cust_id=B.unq_member_id
        where month_year='{month}'
        group by freq_based_recency_seg
        order by count(*)"""

    def get_daypart_trip_stats(self, selected_customer_query):
        """ Generate trip mission distribution by daypart 

        Args:
            selected_customer_query (str): query for user selected criteria

        Returns:
            trip mission distribution by daypart query
        """

        month = self.get_first_day_last_month('%Y-%m')
        return f"""select primary_day_part ,primary_trip_mission,count(*)
        from {app.config["TRIPS_TABLE"]}  stats_table
        inner join 
        ({selected_customer_query})B
        on stats_table.unq_member_id=B.unq_member_id
        where month_year='{month}'
        group by primary_day_part ,primary_trip_mission
        order by count(*)"""

    def get_trip_mission_trip_types(self, selected_customer_query):
        """ Generate trip mission distribution by trip type 

        Args:
            selected_customer_query (str): query for user selected criteria

        Returns:
            trip mission distribution by trip type query
        """

        month = self.get_first_day_last_month('%Y-%m')
        return f"""select primary_trip_mission,primary_trip_type,count(*)
        from {app.config["TRIPS_TABLE"]}  stats_table
        inner join 
        ({selected_customer_query})B
        on stats_table.unq_member_id=B.unq_member_id
        where month_year='{month}'
        group by  primary_trip_mission,primary_trip_type
        order by count(*)"""
