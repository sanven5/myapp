import logging
import pysftp

from DAL.vault_connector import KeyVaultManager

class SFTP_File():
    def get_sftp_creds(self):
        try:

            kv_token = KeyVaultManager().connect_key_vault()

            host = KeyVaultManager().get_secret_value(kv_token,"DDE-CRM-SALESFORCE-TEST-SFTP-HOST")
            username = KeyVaultManager().get_secret_value(kv_token,"DDE-CRM-SALESFORCE-TEST-SFTP-USERID")
            password = KeyVaultManager().get_secret_value(kv_token,"DDE-CRM-SALESFORCE-TEST-SFTP-PASSWORD")
            

            return host,username,password
        except:
            logging.error("Error fethcing values from vault")

    def make_connection(self,host,password,username):
        try:
            ftp = pysftp.Connection(host, username=username, password=password)
            return ftp
        except:
            logging.error('Cannot make connection')

    def sftp_file(self,local_file_path,remote_file_path):
        host,username,password=self.get_sftp_creds()
        sftp_conn=self.make_connection(host,password,username)
        #print(host,password,username)

        try:
            sftp_conn.put(local_file_path,remote_file_path)
            sftp_conn.close()
            return True
        except:
            logging.error("Error in sftp")
            return False
        
