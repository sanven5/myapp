import logging
import re
from app__init__ import app
# declare global constants
ALL = 'All'


class QueryUtils():

    def fix_sql(self, sql_query):

        sql_query = sql_query.strip()
        # remove multiple spaces
        sql_query = re.sub(' +', ' ', sql_query)

        # check if 'where' is last word
        first, *middle, last = sql_query.split()
        if last == 'where':
            sql_query = sql_query.rsplit(' ', 1)[0]

        # fix where and case

        sql_query = sql_query.replace("where and", "where")

        # more than 1 limit clauses

        return sql_query

    def exclude(self, left_tbl, right_tbl, on_key='unq_member_id'):

        query = f"select l.unq_member_id from( {left_tbl}l LEFT JOIN {right_tbl}r ON l.{on_key}=r.{on_key}) where r.unq_member_id is null"
        return query

    def filter_range(self, column, start_value, end_value, condition=True, message=None):
        """filter dataframe column for a range of values

        Args:
            column (str): [description]
            start_value (int or float): [description]
            end_value (int or float): [description]

        Returns:
            range query
        """

        if condition:
            try:
                if message is not None:
                    logging.info(f"customers filtered by {message}")
                return f" and ({column} between {start_value} and {end_value}) "
            except:
                logging.exception("Can't filter in filter_range")
        else:
            return ""

    def filter_query(self, column, value, regex=None, condition=True, message=None):
        """filter  column= value or list of values

        Args:
            column (str): [description]
            value (list or int or str): [description]
            regex ([type], optional): [description]. Defaults to None.

        Returns:
        where clause
        """
        if condition:
            if message is not None:
                logging.info(f"Filtering by {message}")
            if not regex:
                if ALL in value:
                    return ""
                try:

                    return f""" and {column} IN {tuple(value)} """ if len(value) > 1 else f""" and {column} = '{value[0]}' """
                except:
                    logging.exception("Can't filter!")
            else:
                try:

                    return ""
                except:
                    logging.exception("Can't filter regex")
        else:
            return ""
