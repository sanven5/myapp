import logging
import datetime as dt
import logging
import os

from DAL.db_connections import DB_Connections
from Services.utils import read_file_to_spark
from app__init__ import app


class TableExport:

    def read_cohort(self, cohort_file):
        """Read cohort file

        Args:
            export_id_format ([str]): identifier of cohort (member_id/lid)
            cohort_file ([str]): cohort file name
            table_primary_key ([str]): 
        """        
        df = read_file_to_spark(cohort_file)
        df=df.drop_duplicates('unq_member_id')
        #if export_id_format == 'Loyalty-ID':
        #    df=df[['loyalty_id']]
        #else:
        #    df=df[['unq_member_id']]
            
        return df
            
    
    def write_table_spark(self, ip_df, output_table_path, output_table_name,
                    custom_mode="overwrite",
                    partition_cols=[]):

        """
           save table
        """
        #print("partition by " + ",".join(partition_cols))
        (ip_df
         .write.mode(custom_mode)
        #.partitionBy(partition_cols)
         .format("delta")
         .option("path", output_table_path)
         .option("mergeSchema", "true")
         .saveAsTable(output_table_name)
         )
    
    
    def write_to_table(self, cohort_file,key=None):
        df=self.read_cohort(cohort_file)
        df['experiment_id']=key
        
        logging.info('Append  {} '.format( dt.datetime.now().strftime('%H:%M:%S'))) 
        self.write_table_spark(df.to_spark(),
                               app.config["EXPERIMENT_MEMBER_COHORT_TBL_PATH"],
                               app.config["EXPERIMENT_MEMBER_COHORT_TBL_NAME"],
                               custom_mode="append",
                               partition_cols=['experiment_year'])
                               
        
        
            
    
        
        
