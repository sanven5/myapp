import logging
import re

from app__init__ import app

from Services.query_utils import QueryUtils

query_utils_obj = QueryUtils()


class QueryBuilder():

    def check_daypart_rfma(self, user_input, dummy):

        query = f"""select unq_member_id from {app.config["DAYPART_RFMA_TABLE"]} where day_part= '{user_input['select_daypart_rfma'].upper()}' and recency>=0 and """
        query = query + self.filter_rfma(user_input, None, 'daypart', 'recency', 'frequency', 'monetary_val', 'age')

        return query

    def check_channels(self, user_input):
        query = ""
        if(user_input['rewards_customer'] != ""):
            query = query + f"""and rewards_flag= '{str(user_input['rewards_customer']).lower()}' """

        if(user_input['fuel_loyalty_customer'] != ""):
            query = query + f"""and fuel_loyalty_flag='{str(user_input['fuel_loyalty_customer']).lower()}' """

        if(user_input['mco_customer'] != ""):
            query = query + f"""and mc_flag= '{str(user_input['mco_customer']).lower()}' """

        # if(user_input['dw_customer'] != ""):
        #    query = query + f"""and dw_flag= '{user_input['dw_customer']}' """

        if(user_input['now_customer'] != ""):
            query = query + f"""and now_flag= '{str(user_input['now_customer']).lower()}' """

        return query

    def filter_rfma(self, user_input, table_name, prefix, recency_col, freq_col, monetary_col, age_col,
                    recency_range=False, inclusion_flag=""):
        try:
            if table_name is not None:
                query = f"""select unq_member_id from {table_name} where recency>=0 and """
            else:
                query = ""
            query = query + \
                f"""{recency_col}<={user_input[f"{prefix}_recency_end{inclusion_flag}"]} and {freq_col} between {user_input[f"{prefix}_frequency_start{inclusion_flag}"]}
                        and {user_input[f"{prefix}_frequency_end{inclusion_flag}"]} and {age_col} between {user_input[f"{prefix}_age_start{inclusion_flag}"]} and {user_input[f"{prefix}_age_end{inclusion_flag}"]}"""
            if recency_range:

                query = query + \
                    f""" and {recency_col}>={user_input[f'{prefix}_recency_end{inclusion_flag}']}"""
            if monetary_col is not None:
                query = query + \
                    f""" and {monetary_col}>={user_input[f"{prefix}_monetary{inclusion_flag}"]}"""

            return query
        except:
            logging.exception("In filer_rfma:"+prefix)

    def attach_special_character(self, product_value, select_prod_level, final_product_level):
        if select_prod_level == 'PSA_NAME':

            if final_product_level == 'PSA_NAME':
                return product_value
            else:
                return product_value+'_'

        if final_product_level == select_prod_level:
            return '_' + product_value

        else:
            return '_' + product_value+'_'

    def get_hier_value(
            self, user_input, identifier, inclusion_flag, final_prod_level, select_prod_level1, select_prod_level2):

        if final_prod_level == 'SLIN':
            product_values = user_input[f'select_{identifier}_prod_value2'+inclusion_flag] if user_input[f'select_{identifier}_prod_level2' +
                                                                                                         inclusion_flag] == 'SLIN' else user_input[f'select_{identifier}_prod_value1'+inclusion_flag]

        elif final_prod_level:

            product_values = []
            try:

                if 'All' not in user_input['select_prod_value1'+inclusion_flag]:

                    product_values = user_input['select_prod_value1'+inclusion_flag]
                    product_values = [self.attach_special_character(
                        product_value, select_prod_level1, final_prod_level) for product_value in product_values]

                    logging.error(product_values)
                    # and final_prod_level == user_input['select_prod_level2'+inclusion_flag]:
                    if user_input['select_prod_level2' + inclusion_flag] != 'All' and 'All' not in user_input['select_prod_value2' +
                                                                                                              inclusion_flag]:
                        if user_input['select_prod_level1'+inclusion_flag] != 'All' and 'All' not in user_input['select_prod_value1'+inclusion_flag]:
                            product_values_temp = []
                            for product_value in product_values:

                                # temp_pattern_dict=pattern_dict_ref
                                # temp_pattern_dict[select_prod_level1]=product_value
                                for val in user_input['select_prod_value2'+inclusion_flag]:
                                    # temp_pattern_dict[select_prod_level1]=val
                                    val = self.attach_special_character(
                                        val, select_prod_level2, final_prod_level)
                                    product_values_temp.append(
                                        product_value+"%"+val)
                            product_values = product_values_temp

                else:
                    product_values = user_input['select_prod_value2'+inclusion_flag]

                if final_prod_level == 'VENDOR_NAME':
                    product_values_temp = []
                    for vendor in user_input['select_vendor'+inclusion_flag]:
                        for product_value in product_values:
                            product_values_temp.append(
                                f"{product_value}%{vendor}")
                    product_values = product_values_temp

            except Exception as e:
                product_values = None
                logging.exception(str(e)+" at get_hier_value")
        else:
            product_values = None
        return product_values

    def get_prod_rfma_level_value(self, user_input, identifier, inclusion_flag, condition=None):
        if condition:

            if 'All' not in user_input[f"select_{identifier}_vendor{inclusion_flag}"]:
                final_prod_level = "VENDOR_NAME"
         
            elif (
                user_input[f"select_{identifier}_value2{inclusion_flag}"]
                and 'All' not in user_input[f"select_{identifier}_value2{inclusion_flag}"]
            ):

                final_prod_level = user_input[f"select_{identifier}_level2{inclusion_flag}"]
         
            elif (
                user_input[f"select_{identifier}_value1{inclusion_flag}"]
                and "All" not in user_input[f"select_{identifier}_value1{inclusion_flag}"]
            ):

                final_prod_level = user_input[f"select_{identifier}_level1{inclusion_flag}"]
        
            else:
                final_prod_level, final_prod_hier_val = None, None

        else:
            final_prod_level, final_prod_hier_val = None, None

        return final_prod_level 

    def product_cust_attr(self, user_input, identifier, table_name, inclusion_flag, other_param=None,
                          other_param_value=None):

        cust_prod_level = self.get_prod_rfma_level_value(
            user_input, identifier, inclusion_flag, condition=user_input[
                f"check_{identifier}{inclusion_flag}"]
        )

        # filter prod_hier

        cust_prod_hier_val_clause = ""
        
        if 'All' not in user_input[f'select_{identifier}_vendor{inclusion_flag}']:
            cust_prod_hier_val_clause = query_utils_obj.filter_query(
                'vendor_name', user_input[f'select_{identifier}_vendor{inclusion_flag}'])

        else:
            if 'All' not in user_input[f'select_{identifier}_level1{inclusion_flag}']:
                col = user_input[f'select_{identifier}_level1{inclusion_flag}'].lower(
                )
                value = user_input[f'select_{identifier}_value1{inclusion_flag}']
                cust_prod_hier_val_clause = cust_prod_hier_val_clause + \
                    query_utils_obj.filter_query(col, value)
            if 'All' not in user_input[f'select_{identifier}_level2{inclusion_flag}']:
                col = user_input[f'select_{identifier}_level2{inclusion_flag}'].lower(
                )
                value = user_input[f'select_{identifier}_value2{inclusion_flag}']
                cust_prod_hier_val_clause = cust_prod_hier_val_clause + \
                    query_utils_obj.filter_query(col, value)

        query = f"""select unq_member_id from {table_name} where product_hier='{cust_prod_level.lower()}' {cust_prod_hier_val_clause} and recency>=0 """
        if other_param is not None:
            query = query + f"and {other_param}='{other_param_value}' "
        if user_input[f"check_{identifier}_rfma{inclusion_flag}"]:
            query = query + 'and ' + self.filter_rfma(user_input, None, identifier, 'recency', 'frequency',
                                                      'monetary_val', 'age', recency_range=False,
                                                      inclusion_flag=inclusion_flag)
        query = query + ' limit 100000000'
        logging.info(f'Product query: {query}')
        return query

    def check_marketability(self, user_input):
        input_map = {True: 'Y', False: 'N', '': ''}

        query = f"""select loyalty_id from {app.config["MARKETABILITY_TABLE"]} where derived_country ='{user_input['loyalty_program_country']}' """

        query = query + query_utils_obj.filter_query("email_marketable_status",
                                                     input_map[user_input["email_marketable"]],
                                                     condition=user_input["email_marketable"] != "")
        query = query + query_utils_obj.filter_query(
            "sms_marketable_status", input_map[user_input["sms_marketable"]],
            condition=user_input["sms_marketable"] != "")
        query = query + query_utils_obj.filter_query("push_marketable_status", input_map
                                                     [user_input["push_marketable"]],
                                                     condition=user_input["push_marketable"] != "")

        return query

    def check_uc(self, user_input):
        query = f"""select member_id from {app.config["UC_CONTROL_LIST_TABLE"]} """
        return query

    def check_and_call_filter(
            self, base_query, table_name, condition, message, filter_compute_func, inclusion=True,
            join_key='unq_member_id'):
        """Check filter condition, get fiter attributes df and merge with already filtered customer cohort df

        Args:
            condition (booelan): filter condition is to be applied or not
            message (str): logging message
            filter_compute_func (function name): function to be called to get filter attributes df
            filter_func_arguments (arguments): arguments to be passed to filter_compute_func
            inclusion (bool, optional): inclusion or exclusion filter. Defaults to True.

        Returns:
            where clause
        """
        final_query = base_query

        if condition:
            query = filter_compute_func()
            query = query_utils_obj.fix_sql(query)

            query = query+(f"){table_name}" if query.strip().endswith(
                "limit 100000000") else f" limit 100000000){table_name}")
            if inclusion:

                final_query = base_query + \
                    f""" INNER JOIN ({query} ON cust.{join_key}={table_name}.{join_key}"""
            else:
                final_query = base_query + \
                    f""" LEFT JOIN ({query}_excl ON cust.{join_key}={table_name}_excl.{join_key} WHERE {table_name}_excl.unq_member_id IS NULL"""

                logging.info('Removing {message} excluded members')

        return final_query

    def filter_suppressions(cust_attr_df, user_input):
        return ""

    def filter_clv_rfma(self, user_input):

        try:
            if user_input["cust_frequency_start"] == "0" and user_input["cust_frequency_end"] == "0":
                return f"""and frequency<= {user_input["cust_frequency_end"]} """
            else:
                return f"""and recency>=0 and recency <= {user_input["cust_recency_end"]} and frequency>= {user_input["cust_frequency_start"]} and frequency<= {user_input["cust_frequency_end"]} and monetary_val>={user_input["cust_monetary"] } and T between {user_input["cust_age_start"]} and {user_input["cust_age_end"]}"""
        except:
            logging.exception("In filter_clv_rfma")

    def filter_org_hier(self, user_input, inclusion='inclusion'):
        """filters by org hier

        Args:
            user_input (dict): user selection
        Returns:
           where clause
        """

        # all vorg hier values brought into cust_master-- alternatively org hier can be mapped to
        # store numbers and filtering can be done with store numbers only

        col_name = user_input[f"select_org_level_{inclusion}"].lower()
        col_value = user_input[f'select_org_value_{inclusion}']

        if(col_name == 'store_number'):
            col_value = [int(store) for store in user_input[f'select_org_value_{inclusion}'] if store != "TBD"]

        if inclusion == 'inclusion':
            cust_attr_df = query_utils_obj.filter_query(col_name, col_value)
        else:
            if(col_name == 'store_number'):
                cust_attr_df = f"AND {col_name} not in {tuple(col_value)} and {col_name}>=0 """ if len(
                    col_value) > 1 else f""" AND  {col_name} <> {col_value[0]} and {col_name}>=0 """
            else:
                cust_attr_df = f"AND {col_name} not in {tuple(col_value)} and {col_name}<>'null'""" if len(
                    col_value) > 1 else f""" AND  {col_name} <> '{col_value[0]}' and {col_name}<>'null' """
        return cust_attr_df

    def check_channel(self, user_input):
        query = ""
        # query = query + query_utils_obj.filter_query(
        #    "rewards_flag", [user_input["rewards"]], condition=user_input["check_7r"])
        query = query + query_utils_obj.filter_query(
            "now_flag", [user_input["7now_channel"]], condition=user_input["check_7now_channel"])
        query = query + query_utils_obj.filter_query("mc_flag", [
            user_input["mobile_checkout_channel"]], condition=user_input["check_mobile_checkout_channel"])
        query = query + query_utils_obj.filter_query("fuel_flag", [
            user_input["fuel_channel"]], condition=user_input["check_fuel_channel"])

        return query

    def check_demographics(self, user_input):
        query = ""
        if len(user_input["member_gender"]) > 0:
            member_gender_split = [re.sub(r"\(", "", i)
                                   for i in user_input["member_gender"]]

            query = query + \
                query_utils_obj.filter_query("gender", member_gender_split)

            logging.info("Customers filtered by gender")

        if user_input["member_age_start"] != "" or user_input["member_age_end"] != "":
            user_input["member_age_start"] = user_input["member_age_start"] if user_input["member_age_start"] != "" else app.config["CUSTOMER_AGE_MIN"]
            user_input["member_age_end"] = user_input["member_age_end"] if user_input["member_age_end"] != "" else app.config["CUSTOMER_AGE_MAX"]

            query = query + \
                query_utils_obj.filter_range(
                    "customer_age", user_input["member_age_start"], user_input["member_age_end"], True)
            logging.info("Customers filtered by age")
        return query

    def check_channel_rfma(self, user_input, dummy):
        channel_codes = {'7Now': 21, 'MobileCheckout': 20, 'Fuel': 55, '7rewards': 1}
        queries = []
        for channel in channel_codes.keys():
            range_val = True if channel == 21 else False

            if user_input["check_"+channel+"_rfma"]:

                temp_query = self.filter_rfma(
                    user_input, app.config["CHANNEL_RFMA_TABLE"],
                    channel, 'recency', 'frequency', 'monetary_val', 'age', recency_range=range_val)
                temp_query = temp_query + \
                    f""" and txn_channel='{channel_codes[channel]}' limit 100000000"""
                queries.append(temp_query)

        if len(queries) == 2:
            query = f"select x.unq_member_id from ({queries[0]})x INNER JOIN ({queries[1]})y on x.unq_member_id=y.unq_member_id"
        elif len(queries) == 3:
            query = f"select x.unq_member_id from ({queries[0]})x INNER JOIN ({queries[1]})y on x.unq_member_id=y.unq_member_id INNER JOIN ({queries[2]})z on x.unq_member_id=z.unq_member_id "
        else:
            query = f"select x.unq_member_id from ({queries[0]})x"

        return query

    def get_cust_attr(self, user_input):
        cust_query = f"""select distinct cust.unq_member_id,cust.loyalty_id FROM (SELECT unq_member_id,loyalty_id from {app.config["CUSTOMER_MASTER_TABLE"]} where is_primary='true' and loyalty_program_country='{user_input["loyalty_program_country"]}' """
        where_clause = ''


        if 'All' not in user_input["select_org_value_inclusion"]:
            org_query = self.filter_org_hier(user_input, inclusion='inclusion')
            where_clause = where_clause + org_query

        if 'All' not in user_input["select_org_value_exclusion"]:
            org_query = self.filter_org_hier(user_input, inclusion='exclusion')
            where_clause = where_clause + org_query

        # where_clause = where_clause+self.filter_suppressions(user_input)

        if len(
                user_input["member_gender"]) > 0 or (
                user_input["member_age_start"] != "" or user_input["member_age_end"] != ""):
            where_clause = where_clause+self.check_demographics(user_input)

        if user_input['check_age_verified']:
            where_clause = where_clause + f""" and age_verified='true' """

        if user_input["digital_wallet"] != "":
            if user_input["digital_wallet"]:
                where_clause = where_clause + query_utils_obj.filter_range(
                    "dw_balance", user_input["dig_bal_start"],
                    user_input["dig_bal_end"],
                    condition=user_input["digital_wallet"],
                    message='digital wallet')
            else:
                where_clause = where_clause + """and dw_balance<0 """

        where_clause = where_clause+self.check_channels(user_input)

        if user_input["check_p_clv_rfma"]:
            where_clause = where_clause + self.filter_clv_rfma(user_input)
            logging.info("Customers filtered by CLV/RFMA")

        if user_input["points_bal_check"]:
            where_clause = where_clause + \
                f""" and {user_input['loyalty_program_country'].lower()}_points between {user_input["points_start"]} and {user_input["points_end"]} """

        if user_input["check_email_sent"]:
            if user_input["recency_email_sent_end"] != "":
                where_clause = where_clause + \
                    f""" and recency_email_sent>=0 and recency_email_sent <= {user_input["recency_email_sent_end"]} """

            if user_input["recency_email_opened_end"] != "":
                where_clause = where_clause + \
                    f""" and recency_email_open>=0 and recency_email_open <= {user_input["recency_email_opened_end"]} """

            if user_input["recency_email_clicked_end"] != "":
                where_clause = where_clause + \
                    f""" and recency_email_click>=0 and recency_email_click <= {user_input["recency_email_clicked_end"]} """

        if user_input["check_comm_channel_preference"]:
            if user_input["comm_channel_preference"].upper() == "PUSH":

                where_clause = where_clause + \
                    f""" and push_open_rate>=0 and push_open_rate-email_open_rate>= 0 """
            else:
                where_clause = where_clause + \
                    f""" and email_open_rate>=0  and email_open_rate-push_open_rate>= 0 """

        cust_query = query_utils_obj.fix_sql(cust_query)

        cust_query = cust_query+where_clause + " limit 100000000)cust"

        return cust_query

    def check_start_end_customer_segments(self, user_input, customer_id_col, filter_cols_dict):

        queries = []

        # tier_cols={'frequency':'seg_trip_freq','recency':'freq_based_recency_seg'}

        try:
            if True:

                for column_type, column in filter_cols_dict.items():
                    if user_input[f'check_{column_type}']:
                        q = f"""SELECT s.cust_id as unq_member_id FROM
                        (SELECT cust_id FROM
                        {app.config['TIERS_TABLE']} WHERE
                        {column}='{user_input[f"member_{column_type}_start"].capitalize()}'
                        AND month_year='{user_input[f"member_{column_type}_month_start"]}-01' limit 100000000)s"""

                        if user_input[f'check_{column_type}_month_end']:
                            logging.error("Is here")
                            q = q+f""" INNER JOIN
                            (SELECT cust_id from {app.config["TIERS_TABLE"]}
                            WHERE {column}='{user_input[f"member_{column_type}_end"].capitalize()}'
                            AND month_year='{user_input[f"member_{column_type}_month_end"]}-01' limit 100000000)e
                            ON s.{customer_id_col}=e.{customer_id_col}"""

                        queries.append(q)

        except:
            logging.exception("In check_start_end_customer_segments")

        if len(queries) > 1:
            query = f"""SELECT a.unq_member_id from ({queries[0]})a INNER JOIN ({queries[1]})b on a.unq_member_id=b.unq_member_id """
        else:
            query = queries[0]

        logging.info("Customers filtered by segment in 2 months")
        return query

    def check_start_end_customer_segments2(self, user_input, customer_id_col, filter_cols_dict):

        queries = []

        # tier_cols={'frequency':'seg_trip_freq','recency':'freq_based_recency_seg'}

        try:

            for column_type, column in filter_cols_dict.items():
                if user_input[f'check_{column_type}']:
                    queries.append(f"""SELECT s.cust_id as unq_member_id FROM
                    (SELECT cust_id FROM
                    {app.config['TIERS_TABLE']} WHERE
                    {column}='{user_input[f"member_{column_type}_start"].capitalize()}'
                    AND month_year='{user_input[f"member_{column_type}_month_start"]}-01' limit 100000000)s
                    INNER JOIN
                    (SELECT cust_id from {app.config["TIERS_TABLE"]}
                    WHERE {column}='{user_input[f"member_{column_type}_end"].capitalize()}'
                    AND month_year='{user_input[f"member_{column_type}_month_end"]}-01' limit 100000000)e
                    ON s.{customer_id_col}=e.{customer_id_col}""")

        except:
            logging.exception("In check_start_end_customer_segments")

        if len(queries) > 1:
            query = f"""SELECT a.unq_member_id from ({queries[0]})a INNER JOIN ({queries[1]})b on a.unq_member_id=b.unq_member_id """
        else:
            query = queries[0]

        logging.info("Customers filtered by segment in 2 months")
        return query

    def check_primary_segments(self, user_input, customer_id_col, filter_cols_dict):

        queries = []

        try:
            for column_type, column in filter_cols_dict.items():
                if user_input[f'{column_type}'] != "":
                    value = user_input[f"{column_type}"]

                    where_c = f""" IN {tuple(value)} """ if len(value) > 1 else f""" = '{value[0]}' """
                    queries.append(f"""SELECT unq_member_id FROM
                     {app.config['TRIPS_TABLE']} WHERE
                     {column}  {where_c}
                     AND month_year='{user_input[f"{column_type}_month"]}' limit 100000000
                     """)

        except:
            logging.exception("In check_start_end_customer_segments")

        if len(queries) > 1:
            query = f"""SELECT a.unq_member_id from ({queries[0]})a INNER JOIN ({queries[1]})b on a.unq_member_id=b.unq_member_id """
        else:
            query = queries[0]

        logging.info("Customers filtered by segment in 2 months")
        return query

    def get_cust_attr_counts(self, user_input):
        count_dict = {}
        cust_base_query = f"""select count(distinct cust.loyalty_id) FROM (SELECT unq_member_id,loyalty_id from {app.config["CUSTOMER_MASTER_TABLE"]} where is_primary='true'  and loyalty_program_country='{user_input["loyalty_program_country"]}' """
        where_clause = ''
        count_dict['Loyalty program country base'] = cust_base_query + " limit 100000000)cust"

        if 'All' not in user_input["select_org_value_inclusion"]:
            org_query = self.filter_org_hier(user_input, inclusion='inclusion')
            where_clause = where_clause + org_query
            count_dict['Org hier (inclusion)'] = cust_base_query + where_clause + " limit 100000000)cust"

        if 'All' not in user_input["select_org_value_exclusion"]:
            org_query = self.filter_org_hier(user_input, inclusion='exclusion')
            where_clause = where_clause + org_query
            count_dict['Org hier (exclusion)'] = cust_base_query + where_clause + " limit 100000000)cust"

        if len(
                user_input["member_gender"]) > 0 or (
                user_input["member_age_start"] != "" or user_input["member_age_end"] != ""):
            where_clause = where_clause+self.check_demographics(user_input)
            count_dict['Demographic'] = cust_base_query + where_clause + " limit 100000000)cust"

        if user_input['check_age_verified']:
            where_clause = where_clause + f""" and age_verified='true'"""
            count_dict['Age Verified'] = cust_base_query + where_clause + " limit 100000000)cust"

        if (user_input['rewards_customer'] != ""
            or user_input['fuel_loyalty_customer'] != ""
            or user_input['mco_customer'] != ""
            # or user_input['digital_wallet'] != ""
                or user_input['now_customer'] != ""):
            where_clause = where_clause+self.check_channels(user_input)
            count_dict['Customer channels usage'] = cust_base_query + where_clause + " limit 100000000)cust"

        if user_input["digital_wallet"] != "":
            if user_input["digital_wallet"]:
                where_clause = where_clause + query_utils_obj.filter_range(
                    "dw_balance", user_input["dig_bal_start"],
                    user_input["dig_bal_end"],
                    condition=user_input["digital_wallet"],
                    message='digital wallet')
                count_dict['Digital Wallet Balance'] = cust_base_query + where_clause + " limit 100000000)cust"
            else:
                where_clause = where_clause + """ and dw_balance<0 """
                count_dict['No digital wallet balance'] = cust_base_query + where_clause + " limit 100000000)cust"

        if user_input["check_p_clv_rfma"]:
            where_clause = where_clause + self.filter_clv_rfma(user_input)
            count_dict['All txn activity'] = cust_base_query + where_clause + " limit 100000000)cust"

        if user_input["points_bal_check"]:
            where_clause = where_clause + \
                f""" and {user_input['loyalty_program_country'].lower()}_points between {user_input["points_start"]} and {user_input["points_end"]} """
            count_dict['Points balance'] = cust_base_query + where_clause + " limit 100000000)cust"

        if user_input["check_email_sent"]:
            if user_input["recency_email_sent_end"] != "":
                where_clause = where_clause + \
                    f""" and recency_email_sent>=0 and recency_email_sent <= {user_input["recency_email_sent_end"]} """

            if user_input["recency_email_opened_end"] != "":
                where_clause = where_clause + \
                    f""" and recency_email_open>=0 and recency_email_open <= {user_input["recency_email_opened_end"]} """

            if user_input["recency_email_clicked_end"] != "":
                where_clause = where_clause + \
                    f""" and recency_email_click>=0 and recency_email_click <= {user_input["recency_email_clicked_end"]} """

            count_dict['Email Recency '] = cust_base_query + where_clause + " limit 100000000)cust"


        if user_input["check_comm_channel_preference"]:

            if user_input["comm_channel_preference"].upper() == "PUSH":

                where_clause = where_clause + \
                    f""" and push_open_rate>=0 and push_open_rate-email_open_rate>= 0 """
            else:
                where_clause = where_clause + \
                    f""" and email_open_rate>=0  and email_open_rate-push_open_rate>= 0 """

            count_dict['Communication channel pref'] = cust_base_query + where_clause + " limit 100000000)cust"

        cust_base_query = cust_base_query + where_clause + " limit 100000000)cust"

        cust_base_query = query_utils_obj.fix_sql(cust_base_query)

        return count_dict, cust_base_query
