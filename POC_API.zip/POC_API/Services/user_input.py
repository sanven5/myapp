


def create_default_user_input():
    
    """Creates default user selection dictionary

    Returns:
        dict: 
    """
    user_input = {}
    
    user_input["loyalty_program_country"]="US"
    
    #demographic
    user_input["check_demo"] = False
    user_input["member_age_start"] = ""
    user_input["member_age_end"] = ""
    user_input["member_gender"] = []
    
    
    #points
    user_input['points_bal_check']=False
    user_input['points_start']=1
    user_input['points_end']=1000000
    
    #marketability
    #user_input["check_marketability"] = False
    user_input['email_marketable']=""
    user_input['push_marketable']=""
    user_input['sms_marketable']=""
    
    #age verfication
    user_input['check_age_verified']=False
    
    #customer channels
    user_input["now_customer"]=""
    user_input["rewards_customer"]=""
    user_input["fuel_loyalty_customer"]=""
    user_input["mco_customer"]=""
    #dw
    user_input["digital_wallet"] =""
    user_input['dig_bal_start'] =0
    user_input['dig_bal_end']=100000
    
    #customer activity
    user_input["check_p_clv_rfma"] = False
    user_input["cust_recency_start"] = 0
    user_input["cust_recency_end"] = 300000
    user_input["cust_frequency_start"] = 1
    user_input["cust_frequency_end"] = 900000
    user_input["cust_age_start"] = 0
    user_input["cust_age_end"] = 13000
    user_input["cust_monetary"] = 0.0
    
    user_input["p_active"] = 0.0
    user_input["clv"] = 8000
    
    #channel and daypart rfma 

    mediums = ['7rewards','7Now', 'MobileCheckout', 'Fuel','daypart']
    
    for type in mediums:
       
        user_input["check_"+type+"_rfma"] =False
        user_input[type+'_recency_end']=3000
        user_input[f'{type}_frequency_start'] =0
        user_input[f'{type}_frequency_end']=900000
        user_input[f'{type}_age_start']=0
        user_input[f'{type}_age_end']=13000
        user_input[f'{type}_monetary'] =0.0

    user_input['7Now_recency_start']=0
    user_input['select_daypart_rfma']=""
    
    #tiers
    for tier_type in ['frequency','recency']:

        user_input[f'check_{tier_type}_tier']=False
        user_input[f'check_{tier_type}_tier_month_end']=False
        user_input[f"member_{tier_type}_tier_start"] = ""
        user_input[f"member_{tier_type}_tier_end"] = ""
        user_input[f"member_{tier_type}_tier_month_start"] = ""
        user_input[f"member_{tier_type}_tier_month_end"] = ""
    
    
    #trip mission and day part

    user_input["check_primary_trip_mission"]=False
    user_input[f"primary_trip_mission"] = ""
    user_input[f"primary_trip_mission_month"] = ""
    
    user_input["check_primary_daypart"]=False
    user_input["primary_daypart"] = ""
    user_input["primary_daypart_month"] = ""
    
    #Org Hier
    #user_input["check_org_inclusion"] = False
    user_input["select_org_level_inclusion"] = "COUNTRY_CODE"
    user_input["select_org_value_inclusion"] = ['All']

    #user_input["check_org_exclusion"] = False
    user_input["select_org_level_exclusion"] = "COUNTRY_CODE"
    user_input["select_org_value_exclusion"] = ['All']
    
    for inclusion_flag in ['_inclusion', '_exclusion']:
    
        user_input["check_cust_prod"+inclusion_flag] = False
        user_input["select_cust_prod_vendor"+inclusion_flag] = "All"
        user_input["select_cust_prod_level1" + inclusion_flag] = "All"
        user_input["select_cust_prod_value1" + inclusion_flag] = "All"
        user_input["select_cust_prod_level2" + inclusion_flag] = "All"
        user_input["select_cust_prod_value2" + inclusion_flag] = "All"

        user_input["check_cust_prod_rfma"+inclusion_flag] = False
        user_input["cust_prod_recency_end"+inclusion_flag] = 3000
        user_input["cust_prod_frequency_start"+inclusion_flag] = 1
        user_input["cust_prod_frequency_end"+inclusion_flag] = 100000
        user_input["cust_prod_monetary"+inclusion_flag] = 0.00
        user_input["cust_prod_age_start"+inclusion_flag] = 0
        user_input["cust_prod_age_end"+inclusion_flag] = 13000  # to be done

    #inclusion prod rfma
    for medium in ['daypart','txn_channel']:
        inclusion_flag='_inclusion'
        user_input[f"select_{medium}_prod"+inclusion_flag] = False
        user_input[f"check_{medium}_prod"+inclusion_flag] = False
        user_input[f"select_{medium}_prod_vendor"+inclusion_flag] = "All"
        user_input[f"select_{medium}_prod_level1" + inclusion_flag] = "All"
        user_input[f"select_{medium}_prod_value1" + inclusion_flag] = "All"
        user_input[f"select_{medium}_prod_level2" + inclusion_flag] = "All"
        user_input[f"select_{medium}_prod_value2" + inclusion_flag] = "All"

        user_input[f"check_{medium}_prod_rfma"+inclusion_flag] = False
        user_input[f"{medium}_prod_recency_end"+inclusion_flag] = 3000
        user_input[f"{medium}_prod_frequency_start"+inclusion_flag] = 1
        user_input[f"{medium}_prod_frequency_end"+inclusion_flag] = 100000
        user_input[f"{medium}_prod_monetary"+inclusion_flag] = 0.00
        user_input[f"{medium}_prod_age_start"+inclusion_flag] = 0
        user_input[f"{medium}_prod_age_end"+inclusion_flag] = 13000  # to be done
                   
    #email activity
    
    user_input["check_email_sent"]=False
    user_input["recency_email_sent_end"]=""
    
    user_input["recency_email_opened_end"]=""
  
    user_input["recency_email_clicked_end"]=""

    user_input["check_comm_channel_preference"]=False
    user_input["comm_channel_preference"]=""
    
    user_input["uc_flag"]=False
    return user_input

