import os
from DAL.vault_connector import KeyVaultManager
kv_token = KeyVaultManager().connect_key_vault()

# creation of .databricks-connect config file
db_token = KeyVaultManager().get_secret_value(kv_token, os.environ.get('DB_TOKEN'))

db_cluster = os.environ.get('DB_CLUSTER')
db_org = os.environ.get('DB_ORG')

db_connect = {"host": "https://eastus2.azuredatabricks.net",
              "token": str(db_token),
              "cluster_id": str(db_cluster),
              "org_id": str(db_org),
              "port": "8787"}

with open(".databricks-connect", "w") as db_connect_writer:
    db_connect_writer.write(str(db_connect).replace("'", '"'))


# creation of .databrickscfg config file
with open(".databrickscfg", "w") as db_cfg_writer:
    db_cfg_writer.write("[DEFAULT]\n")
    db_cfg_writer.write("host = {}\n".format("https://eastus2.azuredatabricks.net"))
    db_cfg_writer.write("Token = {}".format(str(db_token)))
