import os
import sys

file_dir = os.path.dirname(__file__)
sys.path.append(file_dir)

from core import *
from flask import Blueprint
from flask_restful import reqparse, Api, Resource

# Define Blueprint
Core = Blueprint('Core', __name__)
core = Api(Core)

################################################################################
# Setup the Api resource user data
################################################################################

core.add_resource(User_Data, '/user_data', methods = ['GET','POST','PUT','DELETE'])

# core.add_resource(Prod_Hier, '/prod_level_options', methods = ['GET'])
# core.add_resource(Org_Level_Options, '/org_level_options', methods = ['GET'])
# core.add_resource(Store_Master, '/store_master', methods = ['GET'])
