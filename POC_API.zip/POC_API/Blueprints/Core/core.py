import simplejson as json
from flask import request, jsonify, Blueprint
from flask_restful import reqparse, Api, Resource
from cache_layer import *

import urllib

from DAL import Postgres_DAL


class User_Data(Resource):

    """authorize api request"""
    # decorators = [auth.login_required]

    def get(self):

        # parse params if any
        user_email = request.args.get('email','')

        postgres_DAL = Postgres_DAL()

        return postgres_DAL.get_users_query(user_email)

    def post(self):

        # parse params if any
        user = request.get_json()

        user_obj = {}
        user_obj["email"] = user.get("email", "")
        user_obj["fname"] = user.get("fname", "")
        user_obj["lname"] = user.get("lname", "")
        user_obj["address"] = user.get("address", "")

        postgres_DAL = Postgres_DAL()
        print(user_obj)
        response = postgres_DAL.post_users_query(user_obj)
        print(response)
        if response:
            return({"status": "success"})
        else:
            return({"status": "error", "details": "error in inserting user_data"})


    def delete(self):

        # parse params if any
        user_email = request.args.get('email','')

        postgres_DAL = Postgres_DAL()

        print(user_email)
        response = postgres_DAL.delete_users_query(user_email)
        print(response)
        if response:
            return({"status": "success"})
        else:
            return({"status": "error", "details": "error in deleting user_data"})





    def put(self):

        # parse params if any
        user = request.get_json()

        user_obj = {}
        user_obj["email"] = user.get("email", "")
        user_obj["fname"] = user.get("fname", "")
        user_obj["lname"] = user.get("lname", "")
        user_obj["address"] = user.get("address", "")

        postgres_DAL = Postgres_DAL()
        print(user_obj)
        response = postgres_DAL.update_users_query(user_obj)
        print(response)
        if response:
            return({"status": "success"})
        else:
            return({"status": "error", "details": "error in inserting user_data"})


            

        

