import simplejson as json
from flask import request, jsonify, Blueprint
from flask_restful import reqparse, Api, Resource
from cache_layer import *

import urllib

from Services.file_transfer import SFTP_File

from app__init__ import app

class CRM_SFTP(Resource):

    
    """authorize api request"""
    # decorators = [auth.login_required]
    def post(self):

        # parse params if any
        
        user_input = request.get_json(force=True)
        #local_file_path = request.args.get('local_file_path','')
        #remote_file_path = request.args.get('remote_file_path','')
        print(user_input)
        sftp_obj = SFTP_File()

        return sftp_obj.sftp_file(app.config["BLOB_FILE_PATH"]+user_input['local_file_path'],user_input['remote_file_path'])
    