import os
import sys

file_dir = os.path.dirname(__file__)
sys.path.append(file_dir)

from file_operations import *
from flask import Blueprint
from flask_restful import reqparse, Api, Resource

# Define Blueprint
FileOperations = Blueprint('FileOperations', __name__)
crm_sftp = Api(FileOperations)


################################################################################
# Setup the Api resource routing here
################################################################################

crm_sftp.add_resource(CRM_SFTP, '/crm_sftp', methods = ['POST'])
