import simplejson as json
from flask import request, json, jsonify, Blueprint
from flask_restful import reqparse, Api, Resource
import requests, json
import urllib.parse
import os


# from atlas_api_auth import auth, generate_auth_token


class AuthTokenDep(Resource):

    """authorize api request"""
    # decorators = [auth.login_required]

    def get(self):

        token = generate_auth_token(request.authorization["username"], request.authorization["password"])
        
        return json.loads(json.dumps([{ 'token': token.decode('ascii') }]))




         