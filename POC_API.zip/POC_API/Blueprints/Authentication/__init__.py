import os
import sys

file_dir = os.path.dirname(__file__)
sys.path.append(file_dir)

from authentication import *

Authentication = Blueprint('Authentication', __name__)
authentication = Api(Authentication)

################################################################################
# Setup the Api resource routing here
################################################################################

# authentication.add_resource(MortarAuthToken, '/ab-api-auth-token', methods = ['GET'])

