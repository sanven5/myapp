import memcache, datetime, simplejson as json
import sys,os


#!flask/bin/python
from flask import Flask, jsonify, request, render_template
from flask_restful import Resource, Api
from flask_cors import CORS

# Import blueprints


from Blueprints.Core import Core
# from Blueprints.Cohort import Cohort
# from Blueprints.FileOperations import FileOperations
# from Blueprints.Authentication import Authentication


#################################################################
# Setting Up OS Environment Variables
# sys.setrecursionlimit(10000) # 10000


errors = {

    'KeyError':{
    'message': 'something went wrong on server',
    'status': 500
    }
}

app = Flask(__name__)
CORS(app)

atlas_api = Api(app, errors=errors)
app.config.from_object('config')
app.config['DEBUG'] = True

# print(app.config["BLOB_FILE_PATH"])
# Register Blueprints

app.register_blueprint(Core, url_prefix='/api/atlas')
# app.register_blueprint(Cohort, url_prefix='/api/cohort')
# app.register_blueprint(FileOperations, url_prefix='/api')
# app.register_blueprint(Authentication, url_prefix='/auth')


class Index(Resource):

    def get(self):

        # This constant string specifies the connection success respone

        return jsonify(status="True")


################################################################################
# Setup the Api resource routing here
################################################################################

atlas_api.add_resource(Index, '/')


################################################################################
# Run app
################################################################################


# App Run
if __name__ == '__main__':
    # Use for debug
    #app.run(host='0.0.0.0', port=80)
    # Use for public
    #app.run(host='0.0.0.0')
    app.run(host='0.0.0.0', port=8080)
